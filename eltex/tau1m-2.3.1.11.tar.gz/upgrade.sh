#!/bin/sh

echo 2 > /proc/sys/vm/overcommit_memory
echo 100 > /proc/sys/vm/overcommit_ratio

echo "Start firmware upgrading"
echo "Start firmware upgrading" > /dev/console


#some validation
if [ -f "./fmw_board_type" ]; then
    cur_board=`factory board | sed y/abcdefghijklmnopqrstuvwxyz/ABCDEFGHIJKLMNOPQRSTUVWXYZ/ | sed s/-//g | grep -o ^[A-Z]*[0-9]*`
    case "$cur_board"  in
    "TAU1")    board_type="TAU1";;
    "TAU2")    board_type="TAU2";;
    "TAU4")    board_type="TAU4";;
    "TAU8")    board_type="TAU8";;
    "ESR12V")  board_type="ESR12";;
    "ESR12VF") board_type="ESR12";;
    "ESR14VF") board_type="ESR14";;
    esac

    if [ -z "$board_type" ]; then
        echo "UPGRADE FAIL: wrong factory settings"
        exit 1;
    fi

    fmw_type=`cat ./fmw_board_type`
    if [ "$fmw_type" != "$board_type" ]; then
        echo "UPGRADE FAIL: firmware for $fmw_type but board is $cur_board"
        exit 1;
    fi
fi

md5_cur=`busybox md5sum ./linux.bin | cut -d' ' -f 1`
md5_img=`cat md5_linux`
if [ "$md5_cur" != "$md5_img" ]; then
    echo "UPGRADE FAIL: Incorrect CRC";
    exit 1;
fi

killall igmpproxy udpxy

if [ -f /tmp/fw/utils/upgrade-bin ]; then
    FW_PATH="/tmp/fw"
else
    if [ -f /tmp/auto_fw_upgrade/utils/upgrade-bin ]; then
        FW_PATH="/tmp/auto_fw_upgrade"
    else
        if [ -f /tmp/dhcp_fw_upgrade/utils/upgrade-bin ]; then
            FW_PATH="/tmp/dhcp_fw_upgrade"
        else
            FW_PATH="/tmp/fw_tr069"
        fi
    fi
fi


chmod 777 $FW_PATH/utils/stop_voip
$FW_PATH/utils/stop_voip
chmod 777 $FW_PATH/upgrade-bin
chmod 777 $FW_PATH/utils/upgrade-bin

echo "Stopping VoIP service" > /dev/console
kill `ps| grep "/bin/run_daemon.sh voip"|head -n 1|cut -d' ' -f 2`
echo "" > /tmp/restart_voip

sleep 3
sleep 3
killall voip
sleep 3

cur_major=$(cat /version|cut -d'.' -f 1)
cur_minor=$(cat /version|cut -d'.' -f 2)

#Workaround for 1.5.0
if [ $cur_major -eq 1 ]; then
    if [ $cur_minor -eq 5 ]; then
        mv /bin/factory /bin/_factory
    fi
fi

echo "Upgrade firmware started"
echo "Upgrade firmware started" > /dev/console
$FW_PATH/utils/upgrade-bin ./linux.bin &> /dev/console
RETVAL=$?

if [ "$RETVAL" != "0" ]; then
    if [ "$RETVAL" = "254" ]; then
        echo "UPGRADE FAIL: upgrade process is already in progress" > /dev/console;
        echo "UPGRADE FAIL: upgrade process is already in progress";
        exit 2;
    fi
    echo "UPGRADE FAIL: Error at read/write operation" > /dev/console;
    echo "UPGRADE FAIL: Error at read/write operation";
    exit 1;
fi

if [ $cur_major -eq 1 ]; then
    if [ $cur_minor -eq 5 ]; then
        mv /bin/_factory /bin/factory
    fi
fi


if [[ $cur_board != "ESR12" && $cur_board != "ESR14" ]] ; then
  if [ -e "$FW_PATH/defaults/def.yaml" ];then
      echo "UPGRADE : update def.yaml" > /dev/console;
      echo "UPGRADE : update def.yaml";
      cd $FW_PATH
      cat /proc/mtd | grep "mtd2" > /dev/null
      if [ $? == 0 ]; then
          tar -c defaults | gzip | $FW_PATH/utils/save_def_yaml
      else
          tar -c defaults | gzip | $FW_PATH/utils/save_def_yaml_old
      fi
#     tar -c defaults | gzip | $FW_PATH/utils/save_def_yaml
      cd -
  else
      dd if=/dev/zero of=/dev/mtdblock2 bs=1024 count=64
  fi
fi

if [ $board_type == "TAU4" ] ; then
    bank="`cat /proc/bootbank`"
    if [ "$bank" == "1" ];then
        md5sum set linux2 `cat $FW_PATH/md5_linux`
    else
        md5sum set linux1 `cat $FW_PATH/md5_linux`
    fi
fi
if [ $board_type == "TAU8" ] ; then
    md5sum # > /dev/console
    md5sum set linux2 `cat $FW_PATH/md5_linux`
    md5sum set linux1 `cat $FW_PATH/md5_linux`
fi


echo "UPGRADE SUCCESSFULL" > /dev/console
echo "UPGRADE SUCCESSFULL"
exit 0;
